
Lista de fotos para insertar en la base de datos!!!!
Si le cambiamos los id y los ordenamos por la fecha, las muestraria perfecto en el index pero estaria feo no? 

INSERT INTO `Fotos` (`IdFotos`, `Titulo`, `Descripcion`, `Fecha`, `Pais`, `Album`, `Fichero`, `FRegistro`) VALUES
(1, 'Vintage car', 'Coche Vintage', '2014-9-24', 1, 0, '129H.jpg', '2014-9-24'),
(2, 'Flash Autovia', 'Autovia tope guay', '2014-12-13', 2, 0, 'CK2252.jpg.jpg', '2014-12-13'),
(3, 'Inside', 'Desde dentro', '2014-12-01', 3, 0, 'CK1741.jpg', '2015-12-01'),
(4, 'Marcador', 'Ese marcador maximo', '2010-04-05', 1, 0, 'IMG_3556.jpg', '2010-04-05'),
(5, 'Traffic Light', 'Trafico de luces', '2015-07-20', 3, 0, '6e609595.jpg', '2015-07-20'),
(6, 'Country', 'Pues Country', '2011-11-12', 4, 0, '05502b_o.jpg', '2011-11-12'),
(7, 'Iphone 5', 'Super telefono', '2013-02-06', 2, 0, 'IMG_3822.jpg', '2013-02-06'),
(8, 'Traveler', 'Traveler Maximo', '2015-01-06', 1, 0, 'KgqDYXR.jpg', '2015-01-06');

