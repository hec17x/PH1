  <?php 
    include('cabecera.inc');
    include('inicio.inc');

    include('accesoRegistro.inc');
    include('pie.inc');
  ?>
  
